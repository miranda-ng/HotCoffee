xpk PixelPerfect Iconset for Miranda IM by pk
------

Requirements:
------
- Miranda IM 
  http://miranda-im.org

- Icons library manager 0.0.0.2 ++
  http://miranda-im.org/download/details.php?action=viewfile&id=1895
================================================


Instalation:
------
1. Extract the files from the archive to miranda root folder
2. Apply icons (such icons as Overlay icons required Icolib plugin)
3. Enjoy!

================================================


Description:
------
Big XP/Aqua styled iconset for Miranda IM. Included Main Icons, GLOBAL STATUS, 
ICQ, JABBER,MSN, YAHOO, AIM, WEATHER, GMAIL NOTIFIER, and OVERLAY icons

NEW!! QQ, TLEN, META, RSS, GG


================================================


Any questions/bugs?
------
Just mail me at pk69com@gmail.com


!!You can't use any files from this archive, for other then personal proposes, without my permission.