﻿ Fugue Icons Pack by ksunehckin for Miranda IM (used in build Miranda IM Native - http://code.google.com/p/mimnative/) 

Based on Fugue Icons by Yusuke Kamiyamane (and any icons)
Requirements: Miranda IM v0.9.*.*, supported plugins (see Docs\Supported_plugins.txt)
official site - miranda-planet.com

Набор системных иконок для Miranda IM основанных на Fugue Icons by Yusuke Kamiyamane
Требования : Miranda IM v 0.9.*.*, Поддерживаемые плагины (см Docs\Supported_plugins.txt)
 

Этот Иконпак совместим с Miranda ICE Icon pack patcher (by Induction):
This icon pack is compatible with Miranda ICE Icon pack patcher (by Induction):
http://induction.mirandaim.ru/downloads/resources.zip


!!!УСТАНОВКА!!!
1.	Запускайте iceit.exe

2.	пропишите путь для сборки миранды (где хотите изменить иконки) кликнув [...] и выбирете файл miranda32.exe

3.	в окне ниже выберете типы плагины к-е хотите пропатчить. (или нажмите Select ALL)

4.	Жмите [ICE it...]
если возле плагинов появилась зеленая надпись [succes] то все прошло успешно.


2010-2011. ksunechkin 
Cайт - http://code.google.com/p/mimnative
Donate WM: 
Z162376559505
R179579308420
